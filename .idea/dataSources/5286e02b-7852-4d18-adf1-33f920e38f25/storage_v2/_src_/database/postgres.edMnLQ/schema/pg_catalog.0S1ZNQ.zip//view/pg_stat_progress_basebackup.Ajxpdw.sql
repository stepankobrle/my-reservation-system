create view pg_stat_progress_basebackup
            (pid, phase, backup_total, backup_streamed, tablespaces_total, tablespaces_streamed) as
SELECT pid,
       CASE param1
           WHEN 0 THEN 'initializing'::text
           WHEN 1 THEN 'waiting for checkpoint to finish'::text
           WHEN 2 THEN 'estimating backup size'::text
           WHEN 3 THEN 'streaming database files'::text
           WHEN 4 THEN 'waiting for wal archiving to finish'::text
           WHEN 5 THEN 'transferring wal files'::text
           ELSE NULL::text
           END AS phase,
       CASE param2
           WHEN '-1'::integer THEN NULL::bigint
           ELSE param2
           END AS backup_total,
       param3  AS backup_streamed,
       param4  AS tablespaces_total,
       param5  AS tablespaces_streamed
FROM pg_stat_get_progress_info('BASEBACKUP'::text) s(pid, datid, relid, param1, param2, param3, param4, param5, param6,
                                                     param7, param8, param9, param10, param11, param12, param13,
                                                     param14, param15, param16, param17, param18, param19, param20);

alter table pg_stat_progress_basebackup
    owner to postgres;

grant select on pg_stat_progress_basebackup to public;

