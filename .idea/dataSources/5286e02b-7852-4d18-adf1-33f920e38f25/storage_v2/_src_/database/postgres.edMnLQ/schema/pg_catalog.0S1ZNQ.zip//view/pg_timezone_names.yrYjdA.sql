create view pg_timezone_names(name, abbrev, utc_offset, is_dst) as
SELECT name,
       abbrev,
       utc_offset,
       is_dst
FROM pg_timezone_names() pg_timezone_names(name, abbrev, utc_offset, is_dst);

alter table pg_timezone_names
    owner to postgres;

grant select on pg_timezone_names to public;

